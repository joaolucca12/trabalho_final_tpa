<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\ReservaController;
use App\Http\Controllers\DestinoController;
Route::get('/', function (){
return view('welcome');// A página inicial que você quiser
});
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');
Route::middleware(['auth'])->group(function (){
Route::get('/home', [ReservaController::class, 'index'])->name('home');
Route::get('/minhas-reservas', [ReservaController::class,
'minhasReservas'])->name('minhas-reservas');
Route::get('/destinos', [DestinoController::class, 'index'])->name('destinos.index');
Route::get('/destinos/criar', [DestinoController::class, 'criar'])->name('destinos.criar');
Route::post('/destinos', [DestinoController::class, 'armazenar'])->name('destinos.armazenar');
});
