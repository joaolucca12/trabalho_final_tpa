<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agência de Turismo</title>
    <link rel="stylesheet" href="../css/style.css"> <!-- Link para o CSS -->
</head>
<body>
    <header>
        <h1>Bem-vindo à Nossa Agência de Turismo!</h1>
        <nav>
            <ul>
                <li><a href="#destinos">Destinos</a></li>
                <li><a href="#reservas">Minhas Reservas</a></li>
                <li><a href="#contato">Contato</a></li>
                <li><a href="login.blade.php">Login</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section id="banner">
            <img src="img/destinos-internacionais-2023-capa.jpg" alt="Banner de Destinos" />
            <h2>Explore os Melhores Destinos</h2>
        </section>
        <section id="destinos">
            <h2>Destinos Populares</h2>
            <div class="destino">
                <img src="img/img2.jpg" alt="Destino 1">
                <h3>Praia do Forte</h3>
                
                <p>Praia do Forte é um dos melhores destinos do Litoral Norte da Bahia.</p>

                    <p> Excelente pedida de passeio para quem está em Salvador, mas também uma ótima opção para dias de férias nas praias da Bahia, Praia do Forte é o lugar perfeito para as suas próximas férias no Nordeste. </p>

                    <p>Se o que você busca é um mar incrível, piscinas naturais, vida marinha abundante e um cenário pontilhado por coqueiros a perder de vista, Praia do Forte não pode ficar de fora do seu roteiro.</p>
                <p>Preço: R$ 1500</p>
                <a href="reservar.html">Reservar</a>
            </div>
            <div class="destino">
                <img src="img/banner.jpg" alt="Destino 2">
                <h3>Chapada Diamantina</h3>
                <p>Descrição breve do destino.</p>

                <p>A Chapada Diamantina, na Bahia, é o tipo de destino que causa paixão entre os viajantes.</p>
                 <p> Subir o Morro do Pai Inácio, ver a imensidão da paisagem no alto da Cachoeira da Fumaça, mergulhar nas águas transparentes da Pratinha e assistir ao espetáculo da luz no Poço Azul e no Poço Encantado é apenas o primeiro passo para conhecer um dos mais espetaculares roteiros de natureza do Brasil.</p>
                 <p> Tão espetacular que a cidade de Lençóis, principal base para quem deseja conhecer a região do Parque Nacional da Chapada Diamantina, foi eleita o “Melhor Destino Nacional” de 2019 pelos leitores do Melhores Destinos.</p>
                
                <p>Preço: R$ 1200</p>
                <a href="reservar.html">Reservar</a>
            </div>
            
        </section>
        <section id="contato">
            <h2>Entre em Contato Conosco</h2>
            <p>Email: contato@agenciaturismo.com</p>
            <p>Telefone: (31) 97339-4908</p>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Agência de Turismo. Todos os direitos reservados.</p>
        <p>
            <a href="https://github.com/ViniBraga1" target="_blank">GitHub Vinícius Braga</a> | 
            <a href="https://github.com/BrunoSavino13" target="_blank">GitHub Bruno Savino</a> |
            <a href="https://github.com/ViniciusBretas" target="_blank">GitHub Vinícius Bretas</a> |
            <a href="https://github.com/joaolucca12" target="_blank">GitHub João Lucca</a>
        </p>
    </footer>
</body>
</html>
