<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Destinos - Agência de Turismo</title>
<link rel="stylesheet" href="{{ asset('css/styles.css')}}">
</head>
<body>
<header>
<h1>Destinos Disponíveis</h1>
<a href="{{route('destinos.criar')}}">Adicionar Destino</a>
</header>
<main>
<ul>
@foreach($destinos as $destino)
<li>{{ $destino->nome }}- R$ {{ number_format($destino->preco, 2, ',', '.')}}</li>
@endforeach
</ul>
</main>
</body>
</html>
