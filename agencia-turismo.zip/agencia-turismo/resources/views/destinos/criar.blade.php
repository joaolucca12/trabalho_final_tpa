<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Criar Destino - Agência de Turismo</title>
<link rel="stylesheet" href="{{ asset('css/styles.css')}}">
</head>
<body>
<header>
<h1>Criar Novo Destino</h1>
</header>
<main>
<form method="POST" action="{{route('destinos.armazenar')}}">
@csrf
<div>
<label for="nome">Nome:</label>
<input type="text" name="nome"required>
</div>
<div>
<label for="descricao">Descrição:</label>
<textarea name="descricao"required></textarea>
</div>
<div>
<label for="preco">Preço:</label>
<input type="text" name="preco"required>
</div>
<button type="submit">Adicionar Destino</button>
</form>
</main>
</body>
</html>
